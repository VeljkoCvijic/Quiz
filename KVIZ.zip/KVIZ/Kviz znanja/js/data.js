var jsonData = [
    {
        "q": "Which one is correct team name in NBA?",
        "opt1": "New York Bulls",
        "opt2": "Los Angeles Kings",
        "opt3": "Golden State Warriros",
        "opt4": "Huston Rocket",
        "answer": "Huston Rocket"
    },
    {
        "q": "Namaste' is a traditional greeting in which Asian language?",
        "opt1": "Hindi",
        "opt2": "Mandarin",
        "opt3": "Nepalese",
        "opt4": "Thai",
        "answer": "Hindi"
    },
    {
        "q": "The Spree river flows through which major European capital city?",
        "opt1": "Berlin",
        "opt2": "Paris",
        "opt3": "Rome",
        "opt4": "London",
        "answer": "Berlin"
    },
    {
        "q": "Which famous artist had both a 'Rose Period' and a 'Blue Period'?",
        "opt1": "Pablo Picasso",
        "opt2": "Vincent van Gogh",
        "opt3": "Salvador Dalí",
        "opt4": "Edgar Degas",
        "answer": "Pablo Picasso"
    }

];